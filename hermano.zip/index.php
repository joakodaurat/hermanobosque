<?php
	require_once('config/web.config');
	//require_once(AUTHFILE);
	require_once(CFG_PATH.'/data.config');
	// PEAR
	require_once(INC_PATH.'/pear.inc');
	require_once(INC_PATH.'/comun.php');
	session_start();


	require_once('index.html');

	exit;
?>

