<?php
	require_once(INC_PATH.'/AccesoIntranet.class.php');	
	AccesoIntranet::accederWeb();	
?>
